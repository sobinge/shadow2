#!/usr/bin/env python
#
# WebSploit FrameWork Menu module
# Created By 0x0ptim0us (Fardin Allahverdinazhand)
# Email : 0x0ptim0us@Gmail.Com

from core import wcolors

def main_info():
	ston = wcolors.color.BLUE + "[" + wcolors.color.ENDC
	print ""
	print "\t\t--=" + ston + "WebSploit FrameWork"
	print "\t+---**---==" + ston + "Version :" + wcolors.color.RED + "2.0.3" + wcolors.color.ENDC
	print "\t+---**---==" + ston + "Codename :" + wcolors.color.RED + "CyberTron" + wcolors.color.ENDC
	print "\t+---**---==" + ston + "Available Modules : " + wcolors.color.GREEN + "16" + wcolors.color.ENDC
	print "\t\t--=" + ston + "Update Date : [" + wcolors.color.RED + "r2.0.3-116 9.10.2012" + wcolors.color.ENDC + "]"
	print "\n\n"
